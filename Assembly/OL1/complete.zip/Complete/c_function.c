//Matthew Schroder
//3130
//Open Lab 1
//1/29/2018

#include <stdio.h>

void cPrint(const char *message)
{
write(1,message,77);

return;
}


