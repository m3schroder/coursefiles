#include <string.h>

void print (const char* message);


int main()
{

const char *message = "I kill an ant\nand realize my three children\nhave been watching.\n-Kato Shuson\n";

print(message);

return;

}
